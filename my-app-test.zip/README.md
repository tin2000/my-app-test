# Dùng công cụ 
tailwind.css
Reactjs
# Các thư viện đã cài 
npm install -D tailwindcss
npm i react-router
npm i babel-plugin-react-html-attrs
# cách chạy 
npm start

# cách cài 
dowload giải nén zip 
npm i 
npm start